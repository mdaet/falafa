"use client";

import { motion } from "framer-motion";
import { MapPin } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import { locationTimeline, siteConfig } from "@/lib/data";

export default function Location() {
  return (
    <section id="localisation" className="bg-background py-24 sm:py-32">
      <div className="container-luxe grid grid-cols-1 gap-16 lg:grid-cols-2 lg:gap-12">
        <div>
          <SectionHeading
            eyebrow="La région"
            title="Au cœur du Pays d'Auge"
            description="Idéalement situé entre Honfleur et Deauville, le gîte est le point de départ parfait pour explorer la côte fleurie, ses plages historiques et ses falaises mythiques."
          />

          <div className="mt-12 space-y-0">
            {locationTimeline.map((stop, index) => (
              <motion.div
                key={stop.name}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{
                  duration: 0.55,
                  delay: index * 0.08,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="relative flex gap-6 pb-10 last:pb-0"
              >
                <div className="flex flex-col items-center">
                  <span className="flex h-3 w-3 shrink-0 rounded-full bg-accent ring-4 ring-accent/15" />
                  {index !== locationTimeline.length - 1 && (
                    <span className="mt-1 w-px flex-1 bg-accent/20" />
                  )}
                </div>
                <div className="pb-1">
                  <div className="flex flex-wrap items-baseline gap-2.5">
                    <h3 className="font-display text-lg text-foreground">
                      {stop.name}
                    </h3>
                    <span className="text-xs font-medium uppercase tracking-wide text-secondary">
                      {stop.distance}
                    </span>
                  </div>
                  <p className="mt-1.5 text-sm leading-relaxed text-foreground/60">
                    {stop.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="relative min-h-[420px] overflow-hidden rounded-2xl border border-accent/15 bg-cream-dark lg:sticky lg:top-32 lg:h-[560px]"
        >
          <svg
            viewBox="0 0 500 600"
            className="absolute inset-0 h-full w-full"
            preserveAspectRatio="xMidYMid slice"
          >
            <rect width="500" height="600" fill="#EFE9E0" />
            <path
              d="M0 380 C100 340, 180 410, 260 360 C340 310, 420 350, 500 300"
              stroke="#A3B18A"
              strokeWidth="3"
              fill="none"
              opacity="0.5"
            />
            <path
              d="M0 420 C110 390, 190 450, 270 400 C350 350, 430 400, 500 350"
              stroke="#A3B18A"
              strokeWidth="2"
              fill="none"
              opacity="0.3"
            />
            {[
              [180, 220],
              [300, 180],
              [220, 320],
              [380, 280],
              [120, 140],
            ].map(([cx, cy], i) => (
              <g key={i}>
                <circle cx={cx} cy={cy} r="7" fill="#8B7355" opacity="0.85" />
                <circle
                  cx={cx}
                  cy={cy}
                  r="14"
                  fill="none"
                  stroke="#8B7355"
                  strokeWidth="1"
                  opacity="0.3"
                />
              </g>
            ))}
            <g>
              <circle cx="250" cy="240" r="9" fill="#1D1D1D" />
              <circle
                cx="250"
                cy="240"
                r="18"
                fill="none"
                stroke="#1D1D1D"
                strokeWidth="1.2"
                opacity="0.4"
              />
            </g>
          </svg>

          <div className="absolute bottom-6 left-6 right-6 rounded-xl bg-white/95 p-5 backdrop-blur-sm">
            <div className="flex items-start gap-3">
              <MapPin className="mt-0.5 text-accent" size={20} />
              <div>
                <p className="font-display text-base text-foreground">
                  {siteConfig.address.street}
                </p>
                <p className="text-sm text-foreground/60">
                  {siteConfig.address.postalCode} {siteConfig.address.locality}
                  , {siteConfig.address.region}
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
