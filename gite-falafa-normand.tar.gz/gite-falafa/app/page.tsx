import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Experience from "@/components/Experience";
import Gallery from "@/components/Gallery";
import Location from "@/components/Location";
import Discover from "@/components/Discover";
import Testimonials from "@/components/Testimonials";
import FAQ from "@/components/FAQ";
import BookingCTA from "@/components/BookingCTA";
import Footer from "@/components/Footer";
import TimberDivider from "@/components/ui/TimberDivider";

export default function Home() {
  return (
    <main>
      <Header />
      <Hero />
      <Experience />
      <div className="bg-cream-dark py-2">
        <TimberDivider />
      </div>
      <Gallery />
      <Location />
      <div className="bg-background py-2">
        <TimberDivider />
      </div>
      <Discover />
      <Testimonials />
      <FAQ />
      <BookingCTA />
      <Footer />
    </main>
  );
}
