import type { LucideIcon } from "lucide-react";
import {
  Trees,
  Landmark,
  UtensilsCrossed,
  Wind,
  Users,
  BedDouble,
  Sun,
  Flower2,
  Wifi,
  Car,
  MapPin,
  Star,
} from "lucide-react";

export const siteConfig = {
  name: "Gîte Falafa Normand",
  tagline: "Votre parenthèse normande",
  description:
    "Un gîte authentique à colombages niché au cœur du Pays d'Auge, entre mer, nature et patrimoine normand. Entre Honfleur et Deauville, à deux pas des plages du Débarquement.",
  url: "https://www.gite-falafa-normand.com",
  address: {
    street: "753 Route de Honfleur",
    locality: "Coudray-Rabut",
    postalCode: "14130",
    region: "Calvados",
    country: "FR",
  },
  geo: {
    latitude: 49.30272,
    longitude: 0.18561,
  },
  rating: {
    value: 4.9,
    count: 87,
  },
  phone: "+33 2 31 00 00 00",
};

export type ExperienceCard = {
  icon: LucideIcon;
  title: string;
  description: string;
};

export const experienceCards: ExperienceCard[] = [
  {
    icon: Trees,
    title: "Nature",
    description:
      "Un jardin paysagé d'un demi-hectare, des pommiers centenaires et le silence du bocage normand pour seul horizon.",
  },
  {
    icon: Landmark,
    title: "Patrimoine",
    description:
      "Une bâtisse à pans de bois restaurée dans le respect de l'architecture augeronne, entre Honfleur et le Pays d'Auge.",
  },
  {
    icon: UtensilsCrossed,
    title: "Gastronomie",
    description:
      "Cidre, calvados et camembert à quelques minutes : les producteurs locaux composent votre garde-manger normand.",
  },
  {
    icon: Wind,
    title: "Déconnexion",
    description:
      "Pas de vis-à-vis, pas de bruit de circulation. Seulement le poêle à pellets qui crépite et le vent dans les pommiers.",
  },
];

export type Amenity = {
  icon: LucideIcon;
  label: string;
};

export const amenities: Amenity[] = [
  { icon: Users, label: "4 personnes" },
  { icon: BedDouble, label: "2 chambres" },
  { icon: Sun, label: "Terrasse exposée sud" },
  { icon: Flower2, label: "Jardin clos paysagé" },
  { icon: Wifi, label: "Wifi fibre gratuit" },
  { icon: Car, label: "Parking privé" },
];

export type GalleryImage = {
  src: string;
  alt: string;
  span?: "tall" | "wide" | "normal";
};

export const galleryImages: GalleryImage[] = [
  {
    src: "/images/gite-facade.svg",
    alt: "Façade à colombages du Gîte Falafa Normand au coucher du soleil",
    span: "tall",
  },
  {
    src: "/images/gite-salon.svg",
    alt: "Salon chaleureux avec poêle à pellets et canapé en lin",
    span: "normal",
  },
  {
    src: "/images/gite-chambre1.svg",
    alt: "Chambre principale baignée de lumière naturelle",
    span: "normal",
  },
  {
    src: "/images/gite-cuisine.svg",
    alt: "Cuisine équipée au style normand contemporain",
    span: "wide",
  },
  {
    src: "/images/gite-terrasse.svg",
    alt: "Terrasse en bois donnant sur le jardin paysagé",
    span: "normal",
  },
  {
    src: "/images/gite-jardin.svg",
    alt: "Jardin clos avec pommiers et coin détente",
    span: "tall",
  },
  {
    src: "/images/gite-chambre2.svg",
    alt: "Seconde chambre, ambiance douce et naturelle",
    span: "normal",
  },
  {
    src: "/images/gite-salle-bain.svg",
    alt: "Salle de bain épurée aux matériaux naturels",
    span: "normal",
  },
];

export type LocationStop = {
  name: string;
  distance: string;
  description: string;
};

export const locationTimeline: LocationStop[] = [
  {
    name: "Honfleur",
    distance: "15 min",
    description: "Le Vieux Bassin, ses façades à colombages et ses ateliers d'artistes.",
  },
  {
    name: "Deauville",
    distance: "20 min",
    description: "Les Planches, le casino Belle Époque et la plage la plus élégante du Calvados.",
  },
  {
    name: "Pont-l'Évêque",
    distance: "5 min",
    description: "Le berceau du fromage AOP et les halles normandes du marché du lundi.",
  },
  {
    name: "Plages du Débarquement",
    distance: "45 min",
    description: "Omaha Beach, Arromanches et les mémoriaux du 6 juin 1944.",
  },
  {
    name: "Étretat",
    distance: "1h",
    description: "Les falaises d'aiguille et l'Aiguille creuse chères à Maupassant.",
  },
];

export type DiscoverCard = {
  title: string;
  category: string;
  description: string;
  image: string;
};

export const discoverCards: DiscoverCard[] = [
  {
    title: "Le Vieux Bassin de Honfleur",
    category: "Patrimoine",
    description:
      "Flânez le long du port où Monet posait déjà son chevalet, entre maisons à hautes toitures d'ardoise et galeries d'art.",
    image: "/images/discover-honfleur.svg",
  },
  {
    title: "Les Planches de Deauville",
    category: "Bord de mer",
    description:
      "Une promenade de bois centenaire bordée de cabines aux noms de stars, face à une plage de sable fin à perte de vue.",
    image: "/images/discover-deauville.svg",
  },
  {
    title: "La Route du Cidre",
    category: "Gastronomie",
    description:
      "Traversez les vergers du Pays d'Auge et poussez la porte des cidreries familiales pour une dégustation au calme.",
    image: "/images/discover-cidre.svg",
  },
  {
    title: "Les Falaises d'Étretat",
    category: "Nature",
    description:
      "Aiguille, Porte d'Amont et Porte d'Aval : un des panoramas les plus photographiés de la côte normande.",
    image: "/images/discover-etretat.svg",
  },
];

export type Testimonial = {
  name: string;
  origin: string;
  rating: number;
  date: string;
  text: string;
};

export const testimonials: Testimonial[] = [
  {
    name: "Claire & Antoine",
    origin: "Lyon",
    rating: 5,
    date: "Septembre 2025",
    text: "Un cocon parfait. La décoration est soignée jusqu'au moindre détail, le jardin est magnifique et le calme absolu. Michèle nous a accueillis avec une gentillesse rare, jusqu'à nous offrir des pommes du verger.",
  },
  {
    name: "Sophie M.",
    origin: "Bruxelles",
    rating: 5,
    date: "Juillet 2025",
    text: "Exactement ce qu'on cherchait : authentique sans rien sacrifier au confort. La terrasse au coucher du soleil, le poêle à pellets le soir, et Honfleur à vingt minutes. On reviendra.",
  },
  {
    name: "James & Helen",
    origin: "Londres",
    rating: 5,
    date: "Mai 2025",
    text: "A beautifully maintained property surrounded by gardens. The decor everywhere was thoughtful and the kitchen very well equipped. The perfect base to explore the Normandy coast.",
  },
  {
    name: "Marie L.",
    origin: "Paris",
    rating: 5,
    date: "Avril 2025",
    text: "Le gîte construit dans le respect de l'architecture locale est magnifique, comme neuf et impeccable. Les enfants ont adoré le jardin, nous avons adoré la tranquillité.",
  },
];

export const faqItems = [
  {
    question: "Combien de personnes le gîte peut-il accueillir ?",
    answer:
      "Le Gîte Falafa Normand accueille jusqu'à 4 personnes confortablement, avec deux chambres et un canapé-lit d'appoint dans le salon.",
  },
  {
    question: "Le gîte accepte-t-il les animaux ?",
    answer:
      "Les animaux de compagnie ne sont pas admis au sein de l'établissement, afin de préserver le confort de tous les séjours.",
  },
  {
    question: "À quelle distance se trouve Honfleur et Deauville ?",
    answer:
      "Honfleur se trouve à environ 15 minutes en voiture et Deauville à 20 minutes. Le gîte est idéalement situé entre les deux, au cœur du Pays d'Auge.",
  },
  {
    question: "Quels sont les horaires d'arrivée et de départ ?",
    answer:
      "L'arrivée se fait entre 15h et 16h, et le départ au plus tard à 10h. Merci d'indiquer votre heure d'arrivée prévue lors de la réservation.",
  },
  {
    question: "Le wifi et le parking sont-ils inclus ?",
    answer:
      "Oui, le gîte dispose d'une connexion wifi fibre gratuite et d'un parking privé gratuit sur place.",
  },
];

export const iconMapPin = MapPin;
export const iconStar = Star;
